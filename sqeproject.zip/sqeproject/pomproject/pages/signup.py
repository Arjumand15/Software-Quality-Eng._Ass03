from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.select import Select


class SignUpPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.selector_signup = "body > div.sufee-login.d-flex.align-content-center.flex-wrap > div > div > div.login-form > form > div.register-link.m-t-15.text-center > p > a"
        self.title_id = "title"
        self.fname_id = "firstName"
        self.lname_id = "lastName"
        self.gender_selector = "#gender"
        self.dob_id = "dob"
        self.ssn_id = "ssn"
        self.email_id = "emailAddress"
        self.password_id = "password"
        self.cpassword_id = "confirmPassword"
        self.selector_submit = "body > div.sufee-login.d-flex.align-content-center.flex-wrap > div > div > div.login-form > form > button"
        self.address_id = "address"
        self.locality_id = "locality"
        self.region_id = "region"
        self.postalcode_id = "postalCode"
        self.country_id = "country"
        self.hp_id = "homePhone"
        self.mp_id = "mobilePhone"
        self.wp_id = "workPhone"
        self.agree_id = "agree-terms"
        self.selector_register = "body > div.sufee-login.d-flex.align-content-center.flex-wrap > div > div > div.login-form > form > button"

    def click_signup(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_signup))).click()
        self.driver.find_element_by_id(self.title_id).click()
        self.driver.find_element_by_css_selector("#title > option:nth-child(2)").click()
        self.driver.implicitly_wait(6000)
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.gender_selector))).click()
        self.driver.find_element_by_id(self.fname_id).send_keys("sqa123")
        self.driver.find_element_by_id(self.lname_id).send_keys("test")
        self.driver.find_element_by_id(self.dob_id).send_keys("09/09/2020")
        self.driver.implicitly_wait(6000)
        self.driver.find_element_by_id(self.ssn_id).send_keys("356-96-1734")
        self.driver.find_element_by_id(self.email_id).send_keys("sqatest123@gmail.com")
        self.driver.find_element_by_id(self.password_id).send_keys("1Shayanhaq")
        self.driver.implicitly_wait(6000)
        self.driver.find_element_by_id(self.cpassword_id).send_keys("1Shayanhaq")
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_submit))).click()
        self.driver.find_element_by_id(self.address_id).send_keys("plot no fl/08,block 13,gulistan e johar,karachi, B#406, erum shopping mall & heights karachi")
        self.driver.find_element_by_id(self.locality_id).send_keys("karachi")
        self.driver.find_element_by_id(self.region_id).send_keys("asia")
        self.driver.find_element_by_id(self.postalcode_id).send_keys("75290")
        self.driver.find_element_by_id(self.country_id).send_keys("Pakistan")
        self.driver.find_element_by_id(self.hp_id).send_keys("02134036533")
        self.driver.find_element_by_id(self.mp_id).send_keys("03353230204")
        self.driver.find_element_by_id(self.wp_id).send_keys("03222478515")
        self.driver.find_element_by_id(self.agree_id).click()
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_register))).click()
