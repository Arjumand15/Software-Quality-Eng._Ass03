from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys


class LogoutPage:

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.selector = "#header > div > div.col-sm-5 > div:nth-child(1) > a > img"
        self.selector_logout = "#header > div > div.col-sm-5 > div.user-area.dropdown.show > div > a:nth-child(3)"

    def click_image(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector))).click()

    def click_logout(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_logout))).click()