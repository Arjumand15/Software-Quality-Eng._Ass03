from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class ViewSavingPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.saving = "#savings-menu"
        self.amount_id = "openingBalance"
        self.show_entries = "#transactionTable_length > label > select"

    def click_saving(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.saving))).click()

    def click_view_saving(self):
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, "/html/body/aside/nav/div[2]/ul/li[3]/ul/li[1]/a"))).click()

    def click_on_off(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#firstRow > div:nth-child(2) > div > form > div > label > span.switch-label"))).click()

    def click_show_entries(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.show_entries))).click()
