from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class NewCheckingPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.checking = "#main-menu > ul > li:nth-child(3) > a"
        self.new_checking = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li:nth-child(2) > a"
        self.type_id = "Interest Checking"
        self.ownership_id = "Joint"
        self.name_id = "name"
        self.amount_id = "openingBalance"

    def click_checking(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.checking))).click()

    def click_new_checking(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.new_checking))).click()

    def new_checking_account(self):
        self.driver.find_element_by_id(self.type_id).click()
        self.driver.find_element_by_id(self.ownership_id).click()
        self.driver.find_element_by_id(self.name_id).send_keys("Baraka")
        self.driver.find_element_by_id(self.amount_id).send_keys("9000000000")
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-primary.btn-sm").click()

    def reset(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-primary.btn-sm").click()

