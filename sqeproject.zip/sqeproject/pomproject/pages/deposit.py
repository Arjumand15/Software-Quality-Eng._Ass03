from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class DepositPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.click_account_id = "id"
        self.amount_id = "amount"
        self.transaction = "#main-menu > ul > li:nth-child(5) > a"
        self.deposit = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li:nth-child(1) > a"

    def click_transaction(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.transaction))).click()

    def click_deposit(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.deposit))).click()

    def account(self):
        self.driver.find_element_by_id(self.click_account_id).click()
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#id > option:nth-child(2)"))).click()

    def amount(self, amount):
        self.driver.find_element_by_id(self.amount_id).send_keys("2000000")

    def submit(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-primary.btn-sm").click()

    def reset(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-danger.btn-sm").click()


