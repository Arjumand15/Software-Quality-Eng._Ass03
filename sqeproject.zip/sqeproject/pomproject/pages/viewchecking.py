from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class ViewCheckingPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.checking = "#main-menu > ul > li:nth-child(3) > a"
        self.view_checking = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li:nth-child(1) > a"
        self.amount_id = "openingBalance"
        self.on_off = "#firstRow > div:nth-child(2) > div > form > div > label > span.switch-label"
        self.show_entries = "#transactionTable_length > label > select"

    def click_checking(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.checking))).click()

    def click_view_checking(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.view_checking))).click()

    def click_on_off(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.on_off))).click()

    def click_show_entries(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.show_entries))).click()



