class SigninPage():
    def __init__(self, driver):
        self.driver = driver
        self.username_textbox_id = "username"
        self.password_textbox_id = "password"
        self.rememberme_button_id = "remember-me"
        self.signin_button_id = "submit"

    def enter_username(self, username):
        self.driver.find_element_by_id(self.username_textbox_id).clear()
        self.driver.find_element_by_id(self.username_textbox_id).send_keys("sqepro@gmail.com")

    def enter_password(self, password):
        self.driver.find_element_by_id(self.password_textbox_id).clear()
        self.driver.find_element_by_id(self.password_textbox_id).send_keys("XWBY8B64qu@DdD")

    def click_rememberme(self):
        self.driver.find_element_by_id(self.rememberme_button_id).click()

    def click_signin(self):
        self.driver.find_element_by_id(self.signin_button_id).click()
