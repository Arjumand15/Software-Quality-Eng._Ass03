from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class NewSavingPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.saving = "#savings-menu"
        self.new_saving = "#new-savings-menu-option"
        self.type_id = "Money Market"
        self.ownership_id = "Joint"
        self.name_id = "name"
        self.amount_id = "openingBalance"

    def click_saving(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.saving))).click()

    def click_new_saving(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.new_saving))).click()

    def new_saving_account(self):
        self.driver.find_element_by_id(self.type_id).click()
        self.driver.find_element_by_id(self.ownership_id).click()
        self.driver.find_element_by_id(self.name_id).send_keys("Meezan")
        self.driver.find_element_by_id(self.amount_id).send_keys("7000000000")
        self.driver.find_element_by_css_selector("#newSavingsSubmit").click()

    def reset(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-danger.btn-sm").click()

