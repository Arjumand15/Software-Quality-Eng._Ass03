from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class VisaTransferPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.visa_direct_sel = "#main-menu > ul > li:nth-child(11) > a"
        self.visa_transfer_sel = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li > a"
        self.account_no_id = "extAccount"
        self.amount_id = "extAmount"
        self.submit = "#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button"

    def click_visa_direct(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.visa_direct_sel))).click()

    def click_visa_transfer(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.visa_transfer_sel))).click()

    def enter_account(self):
        self.driver.find_element_by_id(self.account_no_id).click()

    def select_account(self):
        self.driver.find_element_by_css_selector("#extAccount > option:nth-child(2)").click()

    def enter_amount(self, amount):
        self.driver.find_element_by_id(self.amount_id).send_keys("120000")

    def click_submit(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.submit))).click()
