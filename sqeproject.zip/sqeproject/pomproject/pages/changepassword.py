from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys



class ChangePasswordPage():
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.selector = "#header > div > div.col-sm-5 > div:nth-child(1) > a > img"
        self.selector_changepassword = "#header > div > div.col-sm-5 > div.user-area.dropdown.show > div > a:nth-child(2)"
        self.cpass_id = "currentPassword"
        self.epass_id = "newPassword"
        self.copass_id = "confirmPassword"
        self.update_id = "payment-button-amount"

    def click_image(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector))).click()

    def click_changepassword(self):
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_changepassword))).click()

    def current_password(self, cpass):
        self.driver.find_element_by_id(self.cpass_id).send_keys("XWBY8B64qu@DdD")

    def enter_password(self, epass):
        self.driver.find_element_by_id(self.epass_id).send_keys("XWBY8B64qu@Ddu")

    def confirm_password(self, copass):
        self.driver.find_element_by_id(self.copass_id).send_keys("XWBY8B64qu@Ddu")

    def click_updatepassword(self):
        self.driver.find_element_by_id(self.update_id).click()


