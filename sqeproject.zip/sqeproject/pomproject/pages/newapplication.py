from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class NewApplicationPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.new_app_sel = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li > a"
        self.agree_id = "agreeTerms"
        self.apply = "#right-panel > div.content.mt-3 > div > form > div:nth-child(5) > div > div > div.card-body > button"


    def click_digital_credit(self):
        self.driver.find_element_by_css_selector("#main-menu > ul > li:nth-child(7) > a").click()

    def click_new_app(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.new_app_sel))).click()

    def financial_info(self):
        self.driver.find_element_by_id("employmentStatus").click()
        self.driver.find_element_by_css_selector("#employmentStatus > option:nth-child(2)").click()
        self.driver.find_element_by_id("annualIncome").send_keys("100000")
        self.driver.find_element_by_id("monthlyMortgage").send_keys("20000")
        self.driver.find_element_by_id("monthlyAutoLoan").send_keys("400000")
        self.driver.find_element_by_id("monthlyOtherLoan").send_keys("70000")
        self.driver.find_element_by_id("minimumCreditCard").send_keys("20000")
        self.driver.find_element_by_id("monthlySpend").send_keys("10000000000")
        self.driver.find_element_by_id("bankStatus").click()
        self.driver.find_element_by_css_selector("#bankStatus > option:nth-child(2)").click()


    def click_agree(self):
        self.driver.find_element_by_id(self.agree_id).click()

    def click_apply(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.apply))).click()