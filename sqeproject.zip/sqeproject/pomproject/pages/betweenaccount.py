from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC


class BetweenAccountPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.between_account_sel = "#main-menu > ul > li.menu-item-has-children.dropdown.show > ul > li > a"
        self.faccount_id = "fromAccount"
        self.taccount_id = "toAccount"
        self.amount_id = "amount"

    def click_transfer(self):
        self.driver.find_element_by_css_selector("#main-menu > ul > li:nth-child(9)").click()

    def click_between_account(self):
        self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, self.between_account_sel))).click()

    def from_account(self):
        self.driver.find_element_by_id(self.faccount_id).click()
        self.driver.find_element_by_css_selector("#fromAccount > option:nth-child(3)").click()

    def to_account(self):
        self.driver.find_element_by_id(self.taccount_id).click()
        self.driver.find_element_by_css_selector("#toAccount > option:nth-child(2)").click()

    def enter_amount(self, amount):
        self.driver.find_element_by_id(self.amount_id).send_keys("120000")

    def click_submit(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-primary.btn-sm").click()

    def reset(self):
        self.driver.find_element_by_css_selector("#right-panel > div.content.mt-3 > div > div > div > div > form > div.card-footer > button.btn.btn-danger.btn-sm").click()
