from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys


class HomePage:

    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)
        self.notification_id = "notification"
        self.selector_close = "#aboutModal > div > div > div.modal-header > button"
        self.about_id = "aboutLink"
        self.language_id = "language"
        self.search_id = "searchLocations"
        self.zipcode_id = "zipcode"

    def click_dashboard_menu(self):
        self.driver.find_element_by_css_selector("#menuToggle").click()

    def click_about(self):
        self.driver.find_element_by_id(self.about_id).click()
        self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, self.selector_close))).click()

    def click_language(self):
        self.driver.find_element_by_id(self.language_id).click()

    def click_notification(self):
        self.driver.find_element_by_id(self.notification_id).click()

    def click_search(self):
        self.driver.find_element_by_id(self.search_id).click()
        self.driver.find_element_by_id(self.zipcode_id).send_keys("75290")
        self.driver.find_element_by_id(self.zipcode_id).send_keys(Keys.ENTER)

    def click_mail(self):
        self.driver.find_element_by_css_selector("#message").click()


