from selenium import webdriver
import time
import unittest
from pomproject.pages.signin import SigninPage
from pomproject.pages.home import HomePage
from pomproject.pages.logout import LogoutPage

class HomeTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_home(self):
        driver = self.driver
        driver.get("http://dbankdemo.com/login")
        signin = SigninPage(driver)
        signin.enter_username("sqepro@gmail.com")
        signin.enter_password("XWBY8B64qu@DdD")
        signin.click_rememberme()
        signin.click_signin()

        homepage = HomePage(driver)
        homepage.click_dashboard_menu()
        homepage.click_about()
        homepage.click_language
        homepage.click_notification()
        homepage.click_search()
        homepage.click_mail()

        logout = LogoutPage(driver)
        logout.click_image()
        logout.click_logout()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
