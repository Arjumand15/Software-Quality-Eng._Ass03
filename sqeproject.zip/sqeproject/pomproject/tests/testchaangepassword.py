from selenium import webdriver
import time
import unittest
from pomproject.pages.signin import SigninPage
from pomproject.pages.home import HomePage
from pomproject.pages.changepassword import ChangePasswordPage


class SigninTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_myprofile_valid(self):
        driver = self.driver
        driver.get("http://dbankdemo.com/login")

        signin = SigninPage(driver)
        signin.enter_username("sqepro@gmail.com")
        signin.enter_password("XWBY8B64qu@DdD")
        signin.click_rememberme()
        signin.click_signin()

        changepasswordpage = ChangePasswordPage(driver)
        changepasswordpage.click_image()
        changepasswordpage.click_changepassword()
        changepasswordpage.current_password("XWBY8B64qu@DdD")
        changepasswordpage.enter_password("XWBY8B64qu@Ddu")
        changepasswordpage.confirm_password("XWBY8B64qu@Ddu")

        homepage = HomePage(driver)
        homepage.click_image()
        homepage.click_logout()
        time.sleep(3)



    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
