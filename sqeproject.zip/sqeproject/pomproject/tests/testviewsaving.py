from selenium import webdriver
import time
import unittest
from pomproject.pages.signin import SigninPage
from pomproject.pages.viewsaving import ViewSavingPage
from pomproject.pages.logout import LogoutPage


class ViewSavingTest(unittest.TestCase):
    driver = None

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_view_saving_valid(self):
        driver = self.driver
        driver.get("http://dbankdemo.com/login")

        signin = SigninPage(driver)
        signin.enter_username("sqepro@gmail.com")
        signin.enter_password("XWBY8B64qu@DdD")
        signin.click_rememberme()
        signin.click_signin()

        view_saving = ViewSavingPage(driver)
        view_saving.click_saving()
        view_saving.click_view_saving()
        time.sleep(3)
        view_saving.click_on_off()
        view_saving.click_show_entries()

        logout = LogoutPage(driver)
        logout.click_image()
        logout.click_logout()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
