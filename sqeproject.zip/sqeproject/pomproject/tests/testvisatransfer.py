from selenium import webdriver
import time
import unittest
from pomproject.pages.signin import SigninPage
from pomproject.pages.visatransfer import VisaTransferPage
from pomproject.pages.logout import LogoutPage


class VisaTransferTest(unittest.TestCase):
    driver = None

    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_visatranfer(self):
        driver = self.driver
        driver.get("http://dbankdemo.com/login")

        signin = SigninPage(driver)
        signin.enter_username("sqepro@gmail.com")
        signin.enter_password("XWBY8B64qu@DdD")
        signin.click_rememberme()
        signin.click_signin()

        visa_transfer = VisaTransferPage(driver)
        visa_transfer.click_visa_direct()
        visa_transfer.click_visa_transfer()
        visa_transfer.enter_account()
        visa_transfer.select_account()
        visa_transfer.enter_amount("120000")
        visa_transfer.click_submit()
        time.sleep(3)

        logout = LogoutPage(driver)
        logout.click_image()
        logout.click_logout()
        time.sleep(3)

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
