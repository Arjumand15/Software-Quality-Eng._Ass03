from selenium import webdriver
import unittest
import time
from pomproject.pages.signin import SigninPage
from pomproject.pages.signup import SignUpPage


class SignUpTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.driver = webdriver.Chrome()
        cls.driver.implicitly_wait(10)
        cls.driver.maximize_window()

    def test_signup_valid(self):
        driver = self.driver
        driver.get("http://dbankdemo.com/login")
        signup = SignUpPage(driver)
        signup.click_signup()

    @classmethod
    def tearDownClass(cls):
        cls.driver.close()
        cls.driver.quit()
        print("Test completed")
